console.log("Hello there!");
var convertedValue;
var convert = parseInt(1);
function yeet(){

  document.getElementById("text-box").innerHTML = convertedValue;
  if (convert == 1){
    conversion();
  }
  else {
    console.log("stop");
  }
}

function conversion(){
  var indputValue = String(document.getElementById("indput").value);

  if (convert == 1){
    if (indputValue === "a"){
      var convertedValue = (10);
      console.log(10);
      var convert = parseInt(0);
      yeet();

  }}
  else {
    console.log("11");
    console.log(indputValue)
    console.log()

  }
  }
